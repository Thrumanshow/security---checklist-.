
# Security Checklist for 2FA

## 1. Respaldo del Autenticador
- [ ] ¿Tienes una **copia de seguridad** activa en la nube (por ejemplo, en tu cuenta Microsoft)?
- [ ] ¿Has vinculado el autenticador a más de un dispositivo (opcional pero útil)?

## 2. Códigos de Recuperación
- [ ] ¿Has guardado tus **códigos de recuperación** en un lugar seguro (offline o en gestor de contraseñas)?
- [ ] ¿Tienes acceso a tu email o método alternativo por si pierdes el autenticador?

## 3. Sincronización del Tiempo
- [ ] ¿Tu dispositivo tiene la **hora y zona horaria** sincronizadas automáticamente?
- [ ] ¿Los códigos generados coinciden sin errores al iniciar sesión?

## 4. Seguridad del Dispositivo
- [ ] ¿Tu celular tiene **PIN, huella o reconocimiento facial** activado?
- [ ] ¿Tienes alguna app **antirrobo** o copia de seguridad general?

## 5. Revisión Periódica
- [ ] ¿Has revisado recientemente qué **cuentas** están conectadas a tu autenticador?
- [ ] ¿Eliminaste accesos de **dispositivos antiguos** o que ya no usas?

## Ecosistema HormigasAIS-ChatGPT-XOXO

Este repositorio forma parte de los recursos de seguridad para mi **[proyecto HormigasAIS](https://www.linkedin.com/company/hormigasaistudio)**, donde colaboramos sobre temas de automatización, IA y marketing digital.

¡Únete a la comunidad y mantén la seguridad en todo momento!
